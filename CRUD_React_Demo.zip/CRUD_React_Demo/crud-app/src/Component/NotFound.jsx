import notfound from '../Assets/Images/NotFound.jpg';

const NotFound = () => {
    return (
        <img src={notfound}  style={{width: '30%', margin: '80px 0 0 35%'}}/>
    )
}

export default NotFound;